# Sales Intel — CRM MEDDIC & SPIN avec IA

CRM intelligent qui génère automatiquement des rapports MEDDIC et SPIN en recherchant des informations sur vos prospects via le web (Claude + web search).

---

## Stack

- **Next.js 14** (App Router) + TypeScript
- **Tailwind CSS**
- **Supabase** (PostgreSQL — base de données des prospects)
- **NextAuth.js** (authentification par mot de passe)
- **Anthropic Claude** (génération des rapports avec recherche web)
- **Vercel** (hébergement)

---

## Installation locale

### 1. Cloner et installer les dépendances

```bash
git clone <votre-repo>
cd sales-intel
npm install
```

### 2. Créer le projet Supabase

1. Aller sur [supabase.com](https://supabase.com) → New project
2. Récupérer les clés dans **Settings → API**
3. Aller dans **SQL Editor** et coller le contenu de `supabase-schema.sql`

### 3. Configurer les variables d'environnement

```bash
cp .env.local.example .env.local
```

Remplir `.env.local` :

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...

# Anthropic (https://console.anthropic.com/)
ANTHROPIC_API_KEY=sk-ant-...

# NextAuth
NEXTAUTH_SECRET=   # générer avec: openssl rand -base64 32
NEXTAUTH_URL=http://localhost:3000

# Compte admin
ADMIN_EMAIL=admin@votredomaine.com
ADMIN_PASSWORD=VotreMotDePasse!
```

### 4. Lancer en local

```bash
npm run dev
# → http://localhost:3000
```

---

## Déploiement sur Vercel

### 1. Pousser sur GitHub

```bash
git init
git add .
git commit -m "init"
gh repo create sales-intel --private --push
# ou sur github.com → New repository → puis git remote add + git push
```

### 2. Importer sur Vercel

1. Aller sur [vercel.com](https://vercel.com) → **Add New Project**
2. Sélectionner votre repo GitHub
3. Dans **Environment Variables**, ajouter toutes les variables de `.env.local` **sauf** `NEXTAUTH_URL`
4. Ajouter `NEXTAUTH_URL` avec votre URL Vercel finale (ex: `https://sales-intel.vercel.app`)
5. **Deploy** → votre app est en ligne !

### 3. Mise à jour (update)

```bash
git add .
git commit -m "votre modification"
git push
# → Vercel redéploie automatiquement en ~1 minute
```

---

## Structure du projet

```
src/
├── app/
│   ├── api/
│   │   ├── auth/[...nextauth]/   # NextAuth endpoint
│   │   └── prospects/
│   │       ├── route.ts           # GET list, POST create
│   │       └── [id]/
│   │           ├── route.ts       # GET, PATCH, DELETE
│   │           └── report/route.ts # POST → génère rapport IA
│   ├── dashboard/
│   │   ├── layout.tsx             # Layout avec sidebar
│   │   ├── page.tsx               # Dashboard principal
│   │   └── prospects/
│   │       ├── page.tsx           # Liste des prospects
│   │       └── [id]/page.tsx      # Fiche prospect + rapport
│   └── login/page.tsx             # Page de connexion
├── components/
│   ├── layout/Sidebar.tsx
│   └── ui/
│       ├── ProspectCard.tsx
│       ├── ProspectDetailClient.tsx  # Vue rapport avec onglets
│       └── AddProspectButton.tsx
├── lib/
│   ├── auth.ts                    # requireAuth()
│   ├── auth-options.ts            # Config NextAuth
│   ├── utils.ts                   # cn()
│   └── supabase/
│       ├── client.ts              # Client navigateur
│       └── server.ts              # Client serveur + service role
└── types/index.ts                 # Types TypeScript
```

---

## Fonctionnalités

- ✅ Login sécurisé par mot de passe
- ✅ Ajout / suppression de prospects
- ✅ Génération automatique de rapports MEDDIC & SPIN via IA (Claude + web search)
- ✅ Métriques entreprise (CA, effectifs, croissance, position marché)
- ✅ Actualités récentes automatiquement récupérées
- ✅ Score de potentiel (high / medium / low) généré par l'IA
- ✅ Export du brief en `.txt`
- ✅ Persistance en base de données (Supabase PostgreSQL)
- ✅ Auto-deploy GitHub → Vercel

## Évolutions possibles

- Ajouter plusieurs utilisateurs (Supabase Auth)
- Export PDF
- Historique des versions de rapport
- Envoi du brief par email
- Intégration LinkedIn API
- Notifications (nouveau prospect assigné)
