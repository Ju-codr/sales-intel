import { createServiceClient } from '@/lib/supabase/server'
import { requireAuth } from '@/lib/auth'
import { ProspectCard } from '@/components/ui/ProspectCard'
import { AddProspectButton } from '@/components/ui/AddProspectButton'
import { Users } from 'lucide-react'
import type { Prospect } from '@/types'

export const dynamic = 'force-dynamic'

export default async function ProspectsPage() {
  await requireAuth()
  const supabase = createServiceClient()
  const { data: prospects = [] } = await supabase
    .from('prospects')
    .select('id, created_at, updated_at, name, role, company, sector, offer, linkedin_url, score')
    .order('created_at', { ascending: false })

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Prospects</h1>
          <p className="text-sm text-gray-500 mt-1">{prospects.length} prospect{prospects.length !== 1 ? 's' : ''}</p>
        </div>
        <AddProspectButton />
      </div>

      {prospects.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-sm">
          <Users className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <h3 className="text-base font-medium text-gray-900 mb-1">Aucun prospect pour l'instant</h3>
          <p className="text-sm text-gray-500 mb-4">Ajoutez votre premier prospect pour commencer</p>
          <AddProspectButton />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(prospects as Prospect[]).map((p) => (
            <ProspectCard key={p.id} prospect={p} />
          ))}
        </div>
      )}
    </div>
  )
}
