import { createServiceClient } from '@/lib/supabase/server'
import { ProspectCard } from '@/components/ui/ProspectCard'
import { AddProspectButton } from '@/components/ui/AddProspectButton'
import { Users, TrendingUp, Clock, CheckCircle } from 'lucide-react'
import type { Prospect } from '@/types'

export const dynamic = 'force-dynamic'

export default async function DashboardPage() {
  const supabase = createServiceClient()
  const { data: prospects = [] } = await supabase
    .from('prospects')
    .select('id, created_at, updated_at, name, role, company, sector, offer, linkedin_url, score')
    .order('created_at', { ascending: false })

  const total = prospects.length
  const high = prospects.filter((p: Prospect) => p.score === 'high').length
  const analyzed = prospects.filter((p: Prospect) => p.score !== 'unanalyzed').length
  const recent = prospects.filter((p: Prospect) => {
    const d = new Date(p.created_at)
    return Date.now() - d.getTime() < 7 * 24 * 60 * 60 * 1000
  }).length

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
          <p className="text-sm text-gray-500 mt-1">Gérez vos prospects et générez des rapports MEDDIC & SPIN</p>
        </div>
        <AddProspectButton />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Prospects total', value: total, icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'Fort potentiel', value: high, icon: TrendingUp, color: 'text-green-600', bg: 'bg-green-50' },
          { label: 'Analysés', value: analyzed, icon: CheckCircle, color: 'text-purple-600', bg: 'bg-purple-50' },
          { label: 'Ajoutés cette semaine', value: recent, icon: Clock, color: 'text-orange-600', bg: 'bg-orange-50' },
        ].map(stat => (
          <div key={stat.label} className="bg-white rounded-xl border border-gray-200 p-4 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-gray-500">{stat.label}</span>
              <div className={`w-7 h-7 rounded-lg ${stat.bg} flex items-center justify-center`}>
                <stat.icon className={`w-4 h-4 ${stat.color}`} />
              </div>
            </div>
            <div className="text-2xl font-semibold text-gray-900">{stat.value}</div>
          </div>
        ))}
      </div>

      {/* Prospect list */}
      {prospects.length === 0 ? (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-sm">
          <Users className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <h3 className="text-base font-medium text-gray-900 mb-1">Aucun prospect</h3>
          <p className="text-sm text-gray-500 mb-4">Ajoutez votre premier prospect pour générer un rapport MEDDIC & SPIN</p>
          <AddProspectButton />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {(prospects as Prospect[]).map((p) => (
            <ProspectCard key={p.id} prospect={p} />
          ))}
        </div>
      )}
    </div>
  )
}
