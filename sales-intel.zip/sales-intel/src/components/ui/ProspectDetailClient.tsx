'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import {
  ArrowLeft, Sparkles, Loader2, Download, Trash2,
  Building2, TrendingUp, Target, MessageSquare, Star, AlertTriangle,
  ChevronRight,
} from 'lucide-react'
import Link from 'next/link'
import { cn } from '@/lib/utils'
import type { Prospect, SalesReport } from '@/types'

const scoreConfig = {
  high:       { label: 'Fort potentiel', cls: 'bg-green-100 text-green-700' },
  medium:     { label: 'Potentiel moyen', cls: 'bg-yellow-100 text-yellow-700' },
  low:        { label: 'À qualifier', cls: 'bg-red-100 text-red-700' },
  unanalyzed: { label: 'Non analysé', cls: 'bg-gray-100 text-gray-500' },
}

function initials(name: string) {
  return name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
}

const MEDDIC_ITEMS = [
  { key: 'metrics', letter: 'M', label: 'Metrics', desc: 'KPIs à améliorer', color: 'bg-blue-100 text-blue-700' },
  { key: 'economic_buyer', letter: 'E', label: 'Economic Buyer', desc: 'Décideur budget', color: 'bg-teal-100 text-teal-700' },
  { key: 'decision_criteria', letter: 'D', label: 'Decision Criteria', desc: 'Critères de décision', color: 'bg-orange-100 text-orange-700' },
  { key: 'decision_process', letter: 'D', label: 'Decision Process', desc: 'Processus de décision', color: 'bg-amber-100 text-amber-700' },
  { key: 'identify_pain', letter: 'I', label: 'Identify Pain', desc: 'Douleurs identifiées', color: 'bg-red-100 text-red-700' },
  { key: 'champion', letter: 'C', label: 'Champion', desc: 'Champion interne', color: 'bg-purple-100 text-purple-700' },
]

const SPIN_ITEMS = [
  { key: 'situation', label: 'Situation', desc: 'Comprendre le contexte', color: 'border-blue-300 bg-blue-50' },
  { key: 'problem', label: 'Problem', desc: 'Identifier les problèmes', color: 'border-amber-300 bg-amber-50' },
  { key: 'implication', label: 'Implication', desc: 'Amplifier les conséquences', color: 'border-red-300 bg-red-50' },
  { key: 'need_payoff', label: 'Need-Payoff', desc: 'Projeter la valeur', color: 'border-green-300 bg-green-50' },
]

const TABS = [
  { id: 'overview', label: 'Vue d\'ensemble', icon: Building2 },
  { id: 'meddic', label: 'MEDDIC', icon: Target },
  { id: 'spin', label: 'SPIN', icon: MessageSquare },
  { id: 'brief', label: 'Brief', icon: Star },
]

export function ProspectDetailClient({ prospect: initial }: { prospect: Prospect }) {
  const router = useRouter()
  const [prospect, setProspect] = useState(initial)
  const [tab, setTab] = useState('overview')
  const [generating, setGenerating] = useState(false)
  const [loadingStep, setLoadingStep] = useState('')

  const score = scoreConfig[prospect.score] ?? scoreConfig.unanalyzed
  const r: SalesReport | undefined = prospect.report as SalesReport | undefined

  async function generateReport() {
    setGenerating(true)
    const steps = [
      `Recherche web sur ${prospect.company}...`,
      'Analyse des actualités récentes...',
      'Identification des enjeux business...',
      'Construction du framework MEDDIC...',
      'Génération des questions SPIN...',
      'Finalisation du rapport...',
    ]
    let i = 0
    setLoadingStep(steps[0])
    const interval = setInterval(() => {
      i++
      if (i < steps.length) setLoadingStep(steps[i])
    }, 1800)

    try {
      const res = await fetch(`/api/prospects/${prospect.id}/report`, { method: 'POST' })
      const updated = await res.json()
      if (res.ok) {
        setProspect(updated)
        setTab('overview')
      }
    } finally {
      clearInterval(interval)
      setGenerating(false)
      setLoadingStep('')
    }
  }

  async function deleteProspect() {
    if (!confirm(`Supprimer ${prospect.name} ?`)) return
    await fetch(`/api/prospects/${prospect.id}`, { method: 'DELETE' })
    router.push('/dashboard')
  }

  function exportTxt() {
    if (!r) return
    const lines = [
      `RAPPORT SALES INTELLIGENCE`,
      '='.repeat(50),
      `Prospect : ${prospect.name} — ${prospect.role} @ ${prospect.company}`,
      `Secteur  : ${prospect.sector}`,
      `Offre    : ${prospect.offer}`,
      `Généré le: ${new Date(r.generated_at).toLocaleDateString('fr-FR')}`,
      '',
      '--- RÉSUMÉ ENTREPRISE ---',
      r.company_summary,
      '',
      '--- MEDDIC ---',
      ...MEDDIC_ITEMS.map(item => `${item.letter} — ${item.label}:\n${(r.meddic as any)[item.key]}`),
      '',
      '--- QUESTIONS SPIN ---',
      ...SPIN_ITEMS.map(item =>
        `${item.label}:\n${((r.spin as any)[item.key] as string[]).map((q, i) => `${i + 1}. ${q}`).join('\n')}`
      ),
      '',
      '--- POINTS CLÉS ---',
      ...r.talking_points.map((t, i) => `${i + 1}. ${t}`),
      '',
      '--- POINTS DE VIGILANCE ---',
      ...r.risks.map(risk => `• ${risk}`),
    ]
    const blob = new Blob([lines.join('\n')], { type: 'text/plain;charset=utf-8' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = `brief_${prospect.company.replace(/\s+/g, '_')}.txt`
    a.click()
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-gray-500 mb-6">
        <Link href="/dashboard" className="hover:text-gray-900 transition-colors">Dashboard</Link>
        <ChevronRight className="w-3.5 h-3.5" />
        <span className="text-gray-900 font-medium">{prospect.name}</span>
      </div>

      {/* Header */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6 mb-6">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 text-lg font-semibold">
              {initials(prospect.name)}
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">{prospect.name}</h1>
              <p className="text-sm text-gray-500">{prospect.role} · {prospect.company}</p>
              <div className="flex items-center gap-2 mt-2">
                <span className={cn('text-xs px-2 py-0.5 rounded-full font-medium', score.cls)}>{score.label}</span>
                <span className="text-xs text-gray-400">{prospect.sector}</span>
                {r && (
                  <span className="text-xs text-gray-400">
                    · Mis à jour le {new Date(r.generated_at).toLocaleDateString('fr-FR')}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {r && (
              <button onClick={exportTxt} className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                <Download className="w-3.5 h-3.5" /> Exporter
              </button>
            )}
            <button onClick={deleteProspect} className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-red-600 border border-red-200 rounded-lg hover:bg-red-50 transition-colors">
              <Trash2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={generateReport}
              disabled={generating}
              className="flex items-center gap-2 px-4 py-1.5 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 disabled:opacity-60 transition-colors"
            >
              {generating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {r ? 'Regénérer' : 'Générer le rapport IA'}
            </button>
          </div>
        </div>

        {generating && (
          <div className="mt-4 pt-4 border-t border-gray-100">
            <div className="flex items-center gap-2 text-sm text-blue-600">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{loadingStep}</span>
            </div>
            <div className="mt-2 h-1 bg-gray-100 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500 rounded-full animate-pulse" style={{ width: '60%' }} />
            </div>
          </div>
        )}
      </div>

      {/* No report yet */}
      {!r && !generating && (
        <div className="bg-white rounded-xl border border-gray-200 p-12 text-center shadow-sm">
          <Sparkles className="w-10 h-10 text-gray-300 mx-auto mb-3" />
          <h3 className="text-base font-medium text-gray-900 mb-1">Rapport non généré</h3>
          <p className="text-sm text-gray-500 mb-4">
            Cliquez sur « Générer le rapport IA » pour que Claude analyse {prospect.company}<br />
            et produise un brief MEDDIC + SPIN complet avec recherche web.
          </p>
          <button
            onClick={generateReport}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white text-sm font-medium rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Sparkles className="w-4 h-4" /> Générer maintenant
          </button>
        </div>
      )}

      {/* Report tabs */}
      {r && (
        <>
          <div className="flex gap-1 mb-4 bg-white rounded-xl border border-gray-200 p-1 shadow-sm">
            {TABS.map(t => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={cn(
                  'flex items-center gap-1.5 flex-1 justify-center px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                  tab === t.id ? 'bg-blue-600 text-white' : 'text-gray-600 hover:bg-gray-50'
                )}
              >
                <t.icon className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{t.label}</span>
              </button>
            ))}
          </div>

          {tab === 'overview' && <OverviewTab r={r} />}
          {tab === 'meddic' && <MeddicTab r={r} />}
          {tab === 'spin' && <SpinTab r={r} />}
          {tab === 'brief' && <BriefTab r={r} />}
        </>
      )}
    </div>
  )
}

function OverviewTab({ r }: { r: SalesReport }) {
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-3 flex items-center gap-2">
          <Building2 className="w-4 h-4" /> Entreprise
        </h3>
        <p className="text-sm text-gray-700 leading-relaxed mb-4">{r.company_summary}</p>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Object.entries(r.key_metrics).map(([k, v]) => v && (
            <div key={k} className="bg-gray-50 rounded-lg p-3">
              <div className="text-xs text-gray-500 mb-1">
                {{ employees: 'Effectifs', revenue: 'CA estimé', growth: 'Croissance', market_position: 'Position marché' }[k] ?? k}
              </div>
              <div className="text-sm font-semibold text-gray-900">{v}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-3">Actualités récentes</h3>
        <div className="space-y-3">
          {r.recent_news.map((n, i) => (
            <div key={i} className="border-l-2 border-blue-200 pl-3">
              <div className="text-sm font-medium text-gray-900">{n.title}</div>
              <div className="text-xs text-gray-400 mb-1">{n.date}</div>
              <div className="text-xs text-gray-600">{n.impact}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function MeddicTab({ r }: { r: SalesReport }) {
  return (
    <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
      <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-4 flex items-center gap-2">
        <Target className="w-4 h-4" /> Framework MEDDIC
      </h3>
      <div className="space-y-4">
        {MEDDIC_ITEMS.map((item, i) => (
          <div key={item.key}>
            {i > 0 && <div className="border-t border-gray-100 mb-4" />}
            <div className="flex gap-3">
              <div className={cn('w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold shrink-0', item.color)}>
                {item.letter}
              </div>
              <div>
                <div className="text-sm font-medium text-gray-900 mb-0.5">
                  {item.label} <span className="font-normal text-gray-400 text-xs">— {item.desc}</span>
                </div>
                <p className="text-sm text-gray-600 leading-relaxed">{(r.meddic as any)[item.key]}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

function SpinTab({ r }: { r: SalesReport }) {
  return (
    <div className="space-y-4">
      {SPIN_ITEMS.map(item => (
        <div key={item.key} className={cn('bg-white rounded-xl border shadow-sm p-5', item.color)}>
          <h3 className="text-sm font-semibold text-gray-900 mb-0.5">{item.label}</h3>
          <p className="text-xs text-gray-500 mb-3">{item.desc}</p>
          <ol className="space-y-2">
            {((r.spin as any)[item.key] as string[]).map((q, i) => (
              <li key={i} className="flex gap-2.5 text-sm text-gray-700">
                <span className="text-xs font-medium text-gray-400 mt-0.5 shrink-0">Q{i + 1}</span>
                <span className="leading-relaxed">{q}</span>
              </li>
            ))}
          </ol>
        </div>
      ))}
    </div>
  )
}

function BriefTab({ r }: { r: SalesReport }) {
  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-3 flex items-center gap-2">
          <Star className="w-4 h-4" /> Points clés à aborder
        </h3>
        <div className="space-y-2">
          {r.talking_points.map((tp, i) => (
            <div key={i} className="flex gap-3 items-start">
              <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 text-xs font-semibold flex items-center justify-center shrink-0 mt-0.5">
                {i + 1}
              </div>
              <p className="text-sm text-gray-700 leading-relaxed">{tp}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
        <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-3 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" /> Points de vigilance
        </h3>
        <div className="space-y-2">
          {r.risks.map((risk, i) => (
            <div key={i} className="flex gap-2.5 items-start text-sm text-gray-700">
              <span className="text-red-400 mt-1">•</span>
              <span className="leading-relaxed">{risk}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
