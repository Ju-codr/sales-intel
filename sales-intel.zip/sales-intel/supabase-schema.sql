-- Coller dans l'éditeur SQL de Supabase (https://supabase.com/dashboard/project/YOUR_PROJECT/sql)

-- Table prospects
create table if not exists prospects (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  name text not null,
  role text not null default '',
  company text not null,
  sector text not null default '',
  offer text not null default '',
  linkedin_url text,
  score text not null default 'unanalyzed' check (score in ('high','medium','low','unanalyzed')),
  report jsonb
);

-- Trigger updated_at
create or replace function update_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger prospects_updated_at
  before update on prospects
  for each row execute function update_updated_at();

-- Index pour trier par date
create index prospects_created_at_idx on prospects(created_at desc);

-- Row Level Security (désactivé pour l'instant — accès via service role depuis l'API)
alter table prospects disable row level security;
